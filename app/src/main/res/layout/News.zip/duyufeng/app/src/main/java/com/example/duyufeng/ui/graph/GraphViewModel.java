package com.example.duyufeng.ui.graph;

import androidx.lifecycle.ViewModel;

public class GraphViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
